import 'dart:io';

import 'package:animate_do/animate_do.dart';
import 'package:biblechamps/classes/game.dart';
import 'package:biblechamps/services/database.dart';
import 'package:flutter/material.dart';

class PreteensFillInTheGapsGame extends StatefulWidget {
  final int? index;
  final int? valid;
  final int? accumulator;
  final bool? randomMode;

  const PreteensFillInTheGapsGame({
    Key? key,
    this.index,
    this.valid,
    this.accumulator,
    this.randomMode,
  }) : super(key: key);

  @override
  PreteensFillInTheGapsGameState createState() =>
      PreteensFillInTheGapsGameState();
}

class PreteensFillInTheGapsGameState
    extends GameState<PreteensFillInTheGapsGame> {
  PreteensFillInTheGapsGameState() : super('preteens', 'fillinthegaps');

  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  void evaluateGame() {
    selected = true;
    FocusScope.of(context).requestFocus(FocusNode());

    if (formKey.currentState!.validate()) {
      evaluate(true);
    } else {
      evaluate(false);
    }
  }

  double getGapSize(no) {
    List gaps = question!['gaps'].trim().split(' ');
    String gap = gaps[no];

    if (gap.length < 3) {
      return 20;
    } else if (gap.length < 5) {
      return 30;
    } else if (gap.length < 6) {
      return 40;
    } else if (gap.length < 9) {
      return 60;
    } else if (gap.length < 12) {
      return 80;
    } else {
      return 100;
    }
  }

  Widget gap(no) {
    return Container(
      padding: EdgeInsets.zero,
      width: getGapSize(no),
      height: 20,
      child: TextFormField(
        decoration: const InputDecoration(
          contentPadding: EdgeInsets.symmetric(vertical: -22.5),
          errorStyle: TextStyle(
            height: 0,
            fontSize: 0,
          ),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.green,
            ),
          ),
          focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(
              width: 2,
              color: Colors.green,
            ),
          ),
          errorBorder: UnderlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: Colors.red,
            ),
          ),
        ),
        validator: (value) {
          List gaps = question!['gaps'].split(' ');
          String gap = gaps[no];

          if (value?.trim().toLowerCase() == gap.trim().toLowerCase()) {
            return null;
          } else {
            return 'wrong';
          }
        },
        style: const TextStyle(
          fontSize: 16,
          color: Colors.white,
          shadows: [
            Shadow(
              color: Colors.black,
              offset: Offset(-1.25, 1.25),
            ),
          ],
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget gapify() {
    int x = 0;
    String str = question!['question'].replaceAll('*', '|<>|');
    List arr = str.split('|');
    List<Widget> newArr = [];

    for (var value in arr) {
      if (value == '<>') {
        newArr.add(gap(x));
        x++;
      } else {
        newArr.add(Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            color: Colors.white,
            shadows: [
              Shadow(
                color: Colors.black,
                offset: Offset(-1.25, 1.25),
              ),
            ],
          ),
        ));
      }
    }

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Wrap(
          spacing: 0,
          runSpacing: 10,
          alignment: WrapAlignment.center,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: newArr,
        ),
        Container(
          padding: const EdgeInsets.only(top: 10),
          alignment: Alignment.centerRight,
          child: Text(
            question!['scripture'],
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              shadows: [
                Shadow(
                  color: Colors.black,
                  offset: Offset(-1.25, 1.25),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget nextGame() {
    return PreteensFillInTheGapsGame(
      index: index! + 1,
      accumulator: accumulator,
      valid: valid,
    );
  }

  @override
  void initState() {
    super.initState();

    initializeGame(
      widget.index,
      widget.valid,
      widget.accumulator,
      widget.randomMode,
    );

    max = 4;
    value = 250;
    countdown = 90;
    background = 'bg-2.jpg';
  }

  @override
  Widget build(BuildContext context) {
    gameWidget = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ElasticInDown(
          delay: const Duration(milliseconds: 500),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10.0),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: FileImage(File(
                      '${DatabaseService().downloadPath}/images/bg-text.jpg')),
                  fit: BoxFit.cover,
                ),
              ),
              alignment: Alignment.center,
              width: 480,
              height: 185,
              child: Form(
                key: formKey,
                autovalidateMode: AutovalidateMode.disabled,
                child: gapify(),
              ),
            ),
          ),
        ),
        ElasticInUp(
          delay: const Duration(milliseconds: 1000),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: ButtonTheme(
              minWidth: 240.0,
              height: 40,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Colors.green,
                  fixedSize: const Size(240, 40),
                ),
                onPressed: () => !selected ? evaluateGame() : null,
                child: const Text(
                  'Check',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );

    return super.build(context);
  }
}

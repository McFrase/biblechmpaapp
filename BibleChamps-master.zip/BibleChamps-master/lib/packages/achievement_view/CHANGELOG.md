## [0.2.0] - 23/04/2019.

* Fix bug tetStyle

## [0.1.2] - 23/04/2019.

* Update readmi

## [0.1.1] - 23/04/2019.

* Change Color
* Change animantion content
* change textStyle
* Change card retangle or circle
* listener status animation
* change icon (widget)
* change alignment in de screen
* change duration show
* change borderradiun in Retangle mode
* set Title and SubTitle
* align code

## [0.0.1] - 23/04/2019.

* Change Color
* Change animantion content
* change textStyle
* Change card retangle or circle
* listener status animation
* change icon (widget)
* change alignment in de screen
* change duration show
* change borderradiun in Retangle mode
* set Title and SubTitle

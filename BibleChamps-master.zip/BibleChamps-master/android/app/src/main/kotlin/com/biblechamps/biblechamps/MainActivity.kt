package com.biblechamps.biblechamps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
